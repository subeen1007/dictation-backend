package com.dictation;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DictaionApplication {

	public static void main(String[] args) {
		SpringApplication.run(DictaionApplication.class, args);
	}

}
