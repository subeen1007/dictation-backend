package com.dictation.vo;

import java.util.Date;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class Dae_cdVO {
	private String dae_cd;
	private String dae_nm;
	private String use_yn;
	private String input_id;
	private Date input_date;
	private String update_id;
	private Date update_date;
	
}
